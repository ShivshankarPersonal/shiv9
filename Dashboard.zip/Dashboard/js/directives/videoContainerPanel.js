(function () {
    'use strict';
    angular.module("videoContainerPanel", [])
        .directive("videoContainerPanel", function ($timeout, $interval, dashboardFactory) {
            return {
                restrict: 'E',
                templateUrl: "templates/videoContainerPanel.html",
                scope: {
                    title: "@",
                    video: "@"
                },
                link: function ($scope, element, attr) {
                    $scope.videoURLMP4 = "resources/videos/" + $scope.video + ".mp4?" + Date.now();
                    $scope.videoURLOGG = "resources/videos/" + $scope.video + ".ogg?" + Date.now();
                    $scope.videoURLWEBM = "resources/videos/" + $scope.video + ".ogg?" + Date.now();


                    $scope.minimizePanel = function () {
                        var minizeIconElement = angular.element(element).find(angular.element(document.getElementsByClassName('glyphicon-minus')));
                        var originalParent = angular.element(document.getElementsByClassName('video' + attr.number));
                        if (minizeIconElement.length) {
                            angular.element(document.getElementsByClassName('minimizedPanelsHolder')).append(element);
                            angular.element(element).find(angular.element(document.getElementsByClassName('glyphicon-minus'))).removeClass('glyphicon-minus').addClass('glyphicon-modal-window');
                        } else {
                            originalParent.append(element);
                            angular.element(element).find(angular.element(document.getElementsByClassName('glyphicon-modal-window'))).removeClass('glyphicon-modal-window').addClass('glyphicon-minus');
                        }
                    };
                    $scope.maximizePanel = function () {
                        var originalParent = angular.element(document.getElementsByClassName('video' + attr.number));
                        if (angular.element(element).parent().hasClass('maximizePanel')) {
                            angular.element(element).parent().removeClass('maximizePanel');
                        } else {
                            originalParent.append(element);
                            angular.element(element).find(angular.element(document.getElementsByClassName('glyphicon-modal-window'))).removeClass('glyphicon-modal-window').addClass('glyphicon-minus');
                            angular.element(element).parent().addClass('maximizePanel');
                        }
                    };

                    //Stop Video
                    $scope.stopVideo = function () {
                        var videoElementInProcess = angular.element(element).find('video');
                        var videoElementsId = angular.element(videoElementInProcess).attr('id');
                        var videoElement = document.getElementById(videoElementsId);
                        // var progressElementsClassName = angular.element(element).find('.'+'progress'+videoElementsId).attr('class');
                        var progressElement = angular.element(element).find('.' + 'progress' + videoElementsId);

                        videoElement.pause();
                        videoElement.currentTime = 0;
                        progressElement.value = 0;
                    };
                    //Play Video
                    $scope.playVideo = function () {
                        var videoElementInProcess = angular.element(element).find('video');
                        var videoElementsId = angular.element(videoElementInProcess).attr('id');
                        var videoElement = document.getElementById(videoElementsId);
                        videoElement.play()
                    };

                    //Pause Video
                    $scope.pauseVideo = function () {
                        var videoElementInProcess = angular.element(element).find('video');
                        var videoElementsId = angular.element(videoElementInProcess).attr('id');
                        var videoElement = document.getElementById(videoElementsId);
                        videoElement.pause()
                    };
                    //Mute Video
                    $scope.muteVideo = function () {
                        var videoElementInProcess = angular.element(element).find('video');
                        var videoElementsId = angular.element(videoElementInProcess).attr('id');
                        var videoElement = document.getElementById(videoElementsId);
                        videoElement.muted = !videoElement.muted;
                        var muteElement = angular.element(element).find('.mute' + videoElementsId);
                        var isMuteIconPresent = angular.element(muteElement).hasClass('glyphicon-volume-off');
                        if (isMuteIconPresent) {
                            angular.element(muteElement).removeClass('glyphicon-volume-off');
                            angular.element(muteElement).addClass('glyphicon-bullhorn');
                        } else {
                            angular.element(muteElement).addClass('glyphicon-volume-off');
                            angular.element(muteElement).removeClass('glyphicon-bullhorn');
                        }
                    };
                    //Decrease Volume
                    $scope.volumeDown = function () {
                        var videoElementInProcess = angular.element(element).find('video');
                        var videoElementsId = angular.element(videoElementInProcess).attr('id');
                        var videoElement = document.getElementById(videoElementsId);

                        tuneVolumeOfVideoPlayer("-", videoElement)
                    };
                    //Increase Volume
                    $scope.volumeUp = function () {
                        var videoElementInProcess = angular.element(element).find('video');
                        var videoElementsId = angular.element(videoElementInProcess).attr('id');
                        var videoElement = document.getElementById(videoElementsId);

                        tuneVolumeOfVideoPlayer("+", videoElement)
                    };

                    // Progress bar
                    $timeout(function () {
                        // As the video is playing, update the progress bar
                        var videoElementInProcess = angular.element(element).find('video');
                        var videoElementsId = angular.element(videoElementInProcess).attr('id');
                        var video = document.getElementById(videoElementsId);
                        if (video.readyState > 0) {
                            // console.log(video.duration)
                            $scope["videoDuration" + $scope.video] = video.duration;
                            // console.log(video.duration)
                        }

                        video.addEventListener('durationchange', onDurationChange, false);
                        $scope.timingMap = {};
                        function onDurationChangeDuringVideoPlay(me) {
                            $scope.timingMap[me.id] = parseInt(me.currentTime).toString() + "/" + parseInt(me.duration).toString();
                            console.log(parseInt(me.currentTime).toString() + "/" + parseInt(me.duration).toString())
                        }

                        function onDurationChange() {
                            $scope.timingMap[this.id] = parseInt(this.currentTime).toString() + "/" + parseInt(this.duration).toString();
                        }

                        $timeout(function () {
                            $scope.getDurationDetails = function (videoNumber) {
                                return $scope.timingMap[videoNumber];
                            };
                        }, 200);

                        // console.log($scope["videoDuration"+$scope.video])
                        // If the browser doesn't support the progress element, set its state for some different styling
                        var supportsProgress = (document.createElement('progress').max !== undefined);
                        if (!supportsProgress) progress.setAttribute('data-state', 'fake');

                        video.addEventListener('ended', onVideoEnd, false);
                        function onVideoEnd() {
                            video.load();
                            video.play();
                        }

                        video.addEventListener('timeupdate', function () {
                            var videoElementsId = angular.element(videoElementInProcess).attr('id');
                            // var progressElement = angular.element(element).find('.' + 'progress' + videoElementsId);
                            var progressElement = document.getElementsByClassName('.' + 'progress' + videoElementsId);

                            var progressElement = angular.element(element).find('.' + 'progress' + videoElementsId);
                            var progressBar = angular.element(progressElement).find('.progress-bar');
                            // For mobile browsers, ensure that the progress element's max attribute is set
                            // if (!progressElement.getAttribute('max')) progressElement.setAttribute('max', video.duration);
                            if (!angular.element(progressElement).attr('max')) {
                                angular.element(progressElement).attr('max', video.duration)
                            }
                            // progressElement.value = video.currentTime;
                            angular.element(progressElement).attr('value', video.currentTime)
                            // progressBar.style.width = Math.floor((video.currentTime / video.duration) * 100) + '%';
                            var width = Math.floor((video.currentTime / video.duration) * 100) + '%';
                            angular.element(progressElement).attr('style', width);
                            onDurationChangeDuringVideoPlay(this);
                        });

                        // React to the user clicking within the progress bar
                        var progressElement = document.getElementById('progress' + videoElementsId);
                        progressElement.addEventListener('click', function (e) {
                            var videoElementInProcess = angular.element(element).find('video');
                            var videoElementsId = angular.element(videoElementInProcess).attr('id');
                            // var progressElement = angular.element(element).find('.' + 'progress' + videoElementsId);
                            var progressElement = document.getElementById('progress' + videoElementsId);
                            //var pos = (e.pageX  - this.offsetLeft) / this.offsetWidth; // Also need to take the parent into account here as .controls now has position:relative
                            var pos = (e.pageX - (this.offsetLeft + this.offsetParent.offsetLeft)) / this.offsetWidth;
                            progressElement.currentTime = pos * video.duration;
                        });
                    }, 10);


                    //Full Screen Video
                    $scope.fullScreenVideo = function () {
                        var videoElementInProcess = angular.element(element).find('video');
                        var videoElementsId = angular.element(videoElementInProcess).attr('id');
                        var videoElement = document.getElementById(videoElementsId);
                        var videoContainer = videoElement.parentNode;
                        handleFullscreen(videoElement, videoContainer);

                    };
                    // Checks if the document is currently in fullscreen mode
                    var isFullScreen = function () {
                        return !!(document.fullScreen || document.webkitIsFullScreen || document.mozFullScreen || document.msFullscreenElement || document.fullscreenElement);
                    }

                    // Fullscreen
                    // Set the video container's fullscreen state
                    var setFullscreenData = function (state, videoContainer) {

                        videoContainer.setAttribute('data-fullscreen', !!state);
                        // Set the fullscreen button's 'data-state' which allows the correct button image to be set via CSS
                        fullscreen.setAttribute('data-state', !!state ? 'cancel-fullscreen' : 'go-fullscreen');
                    }
                    var handleFullscreen = function (video, videoContainer) {
                        // If fullscreen mode is active...
                        if (isFullScreen()) {
                            // ...exit fullscreen mode
                            // (Note: this can only be called on document)
                            if (document.exitFullscreen) document.exitFullscreen();
                            else if (document.mozCancelFullScreen) document.mozCancelFullScreen();
                            else if (document.webkitCancelFullScreen) document.webkitCancelFullScreen();
                            else if (document.msExitFullscreen) document.msExitFullscreen();
                            setFullscreenData(false);
                        }
                        else {
                            // ...otherwise enter fullscreen mode
                            // (Note: can be called on document, but here the specific element is used as it will also ensure that the element's children, e.g. the custom controls, go fullscreen also)
                            if (videoContainer.requestFullscreen) videoContainer.requestFullscreen();
                            else if (videoContainer.mozRequestFullScreen) videoContainer.mozRequestFullScreen();
                            else if (videoContainer.webkitRequestFullScreen) {
                                // Safari 5.1 only allows proper fullscreen on the video element. This also works fine on other WebKit browsers as the following CSS (set in styles.css) hides the default controls that appear again, and
                                // ensures that our custom controls are visible:
                                // figure[data-fullscreen=true] video::-webkit-media-controls { display:none !important; }
                                // figure[data-fullscreen=true] .controls { z-index:2147483647; }
                                video.webkitRequestFullScreen();
                            }
                            else if (videoContainer.msRequestFullscreen) videoContainer.msRequestFullscreen();
                            setFullscreenData(true);
                        }
                    };
                    // Listen for fullscreen change events (from other controls, e.g. right clicking on the video itself)
                    document.addEventListener('fullscreenchange', function (e) {
                        setFullscreenData(!!(document.fullScreen || document.fullscreenElement));
                    });
                    document.addEventListener('webkitfullscreenchange', function () {
                        setFullscreenData(!!document.webkitIsFullScreen);
                    });
                    document.addEventListener('mozfullscreenchange', function () {
                        setFullscreenData(!!document.mozFullScreen);
                    });
                    document.addEventListener('msfullscreenchange', function () {
                        setFullscreenData(!!document.msFullscreenElement);
                    });

                    var tuneVolumeOfVideoPlayer = function (direction, video) {
                        if (direction) {
                            var currentVolume = Math.floor(video.volume * 10) / 10;
                            if (direction === '+') {
                                if (currentVolume < 1) video.volume += 0.1;
                            }
                            else if (direction === '-') {
                                if (currentVolume > 0) video.volume -= 0.1;
                            }
                            // If the volume has been turned off, also set it as muted
                            // Note: can only do this with the custom control set as when the 'volumechange' event is raised, there is no way to know if it was via a volume or a mute change
                            if (currentVolume <= 0) video.muted = true;
                            else video.muted = false;
                        }
                    }

                    // Modal
                    $scope.onViewAllComments = function (e) {
                        var videoNumber = parseInt(angular.element(e.target).attr('number')) - 1;
                        $scope.$emit("displayAllComments",{videoNumber:videoNumber});
                        // $scope.allComments = dashboardFactory.top4Videos[videoNumber].videoComments;

                        $('#myModal').modal({
                            keyboard: false
                        })
                    };


                }
            }
        })
        .filter("trustUrl", ['$sce', function ($sce) {
            return function (recordingUrl) {
                return $sce.trustAsResourceUrl(recordingUrl);
            };
        }]);
})();

